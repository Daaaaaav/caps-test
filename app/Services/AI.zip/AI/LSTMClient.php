<?php

namespace App\Services\AI;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * Improved LSTM Client Service
 *
 * Communicates with the Python FastAPI forecasting microservice.
 *
 * Features:
 *  Holidayaware forecasting
 *  Lag feature forecasting
 *  Rolling average forecasting
 *  Automatic fallback prediction
 *  Extended metrics support
 *  Improved logging
 */
class LSTMClient
{
    /**
     * Base URL of Python AI service
     */
    private string $baseUrl;

    /**
     * Request timeout in seconds
     */
    private int $timeout;

    /**
     * Minimum historical records required
     */
    private int $minimumDataPoints = 45;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this>baseUrl = env(
            'LSTM_SERVICE_URL',
            'http://127.0.0.1:8001'
        );

        $this>timeout = env(
            'LSTM_SERVICE_TIMEOUT',
            30
        );
    }

    // HEALTH CHECK
    /**
     * Check if AI forecasting service is available
     */
    public function isAvailable(): bool
    {
        try {

            $response = Http::timeout(2)
                >get($this>baseUrl . '/');

            return $response>successful();

        } catch (\Exception $e) {

            Log::warning('LSTM service unavailable', [
                'error' => $e>getMessage(),
            ]);

            return false;
        }
    }

    // MAIN PREDICTION
    /**
     * Generate AI forecast predictions
     *
     * @param array $timeSeries
     * @param int $forecastDays
     * @param bool $useDummyData
     *
     * @return array|null
     */
    public function predict(
        array $timeSeries,
        int $forecastDays = 7,
        bool $useDummyData = false
    ): ?array {

        try {
            // Validate minimum data
            if (
                !$useDummyData &&
                count($timeSeries) < $this>minimumDataPoints
            ) {

                Log::warning(
                    'Insufficient historical data for LSTM forecast',
                    [
                        'required' => $this>minimumDataPoints,
                        'received' => count($timeSeries),
                    ]
                );

                return null;
            }

            // Format payload
            $data = array_map(function ($point) {

                return [
                    'date' => $point['date'],
                    'count' => (float) $point['count'],
                ];

            }, $timeSeries);

            $payload = [
                'data' => $data,
                'forecast_days' => $forecastDays,
                'use_dummy_data' => $useDummyData,
            ];

            // Send request to Python service
            $response = Http::timeout($this>timeout)
                >post(
                    $this>baseUrl . '/predict',
                    $payload
                );

            // Handle failed responses
            if (!$response>successful()) {

                Log::warning(
                    'LSTM service returned unsuccessful response',
                    [
                        'status' => $response>status(),
                        'body' => $response>body(),
                    ]
                );
                return null;
            }
            $result = $response>json();

            // Log forecast metrics
            Log::info('LSTM prediction generated', [
                'model' => $result['model'] ?? 'unknown',
                'rmse' => $result['metrics']['rmse'] ?? null,
                'mae' => $result['metrics']['mae'] ?? null,
                'mape' => $result['metrics']['mape'] ?? null,
                'training_samples' =>
                    $result['training_samples'] ?? null,
                'test_samples' =>
                    $result['test_samples'] ?? null,
            ]);


            // Return formatted response
            return [
                'method' => 'lstm',
                'model' =>
                    $result['model']
                    ?? 'Improved LSTM Forecast Model',
                'metrics' => [
                    'rmse' =>
                        $result['metrics']['rmse']
                        ?? 0,
                    'mae' =>
                        $result['metrics']['mae']
                        ?? 0,
                    'mape' =>
                        $result['metrics']['mape']
                        ?? 0,
                ],
                'features_used' =>
                    $result['features_used']
                    ?? [],
                'predictions' =>
                    $result['predictions']
                    ?? [],
                'data_source' =>
                    $result['data_source']
                    ?? 'unknown',
                'weekly_summary' =>
                    $result['weekly_summary']
                    ?? null,
                'training_samples' =>
                    $result['training_samples']
                    ?? 0,
                'test_samples' =>
                    $result['test_samples']
                    ?? 0,
            ];
        } catch (\Exception $e) {

            Log::error('LSTM prediction failed', [
                'error' => $e>getMessage(),
                'url' => $this>baseUrl,
                'forecast_days' => $forecastDays,
            ]);
            return null;
        }
    }
    // 3WEEK FORECAST
    /**
     * Generate 21day forecast
     *
     * @param array $timeSeries
     * @param bool $useDummyData
     *
     * @return array|null
     */
    public function predict3Weeks(
        array $timeSeries = [],
        bool $useDummyData = false
    ): ?array {

        try {
            // Use dummy data if insufficient
            if (
                empty($timeSeries) ||
                count($timeSeries) < $this>minimumDataPoints
            ) {

                $useDummyData = true;

                $timeSeries = [[
                    'date' => date('Ymd'),
                    'count' => 0,
                ]];
            }

            //
            // Format request
            //

            $data = array_map(function ($point) {

                return [
                    'date' => $point['date'],
                    'count' => (float) $point['count'],
                ];

            }, $timeSeries);

            $payload = [
                'data' => $data,
                'forecast_days' => 21,
                'use_dummy_data' => $useDummyData,
            ];

            // Call Python service
            $response = Http::timeout($this>timeout)
                >post(
                    $this>baseUrl . '/predict3weeks',
                    $payload
                );

            if (!$response>successful()) {

                Log::warning(
                    '3week forecast request failed',
                    [
                        'status' => $response>status(),
                        'body' => $response>body(),
                    ]
                );

                return null;
            }

            return $response>json();

        } catch (\Exception $e) {

            Log::error(
                'LSTM 3week prediction failed',
                [
                    'error' => $e>getMessage(),
                ]
            );

            return null;
        }
    }

    // DEMO ENDPOINT
    public function getDemo(): ?array
    {
        try {

            $response = Http::timeout($this>timeout)
                >get($this>baseUrl . '/demo');

            if (!$response>successful()) {

                Log::warning('LSTM demo endpoint failed', [
                    'status' => $response>status(),
                ]);

                return null;
            }

            return $response>json();

        } catch (\Exception $e) {

            Log::error('LSTM demo failed', [
                'error' => $e>getMessage(),
            ]);

            return null;
        }
    }
    // FALLBACK FORECASTING
    public function predictWithFallback(
        array $timeSeries,
        int $forecastDays = 7
    ): array {

        // Try AI forecast first
        $lstmResult = $this>predict(
            $timeSeries,
            $forecastDays
        );

        if ($lstmResult !== null) {

            return $lstmResult;
        }

        // Fallback forecast
        Log::info(
            'Using fallback moving average forecast'
        );

        return $this>simpleMovingAverage(
            $timeSeries,
            $forecastDays
        );
    }

    // SIMPLE MOVING AVERAGE FALLBACK
    private function simpleMovingAverage(
        array $timeSeries,
        int $forecastDays
    ): array {

        if (empty($timeSeries)) {

            return [

                'method' => 'fallback',

                'model' => 'Simple Moving Average',

                'metrics' => [
                    'rmse' => 0,
                    'mae' => 0,
                    'mape' => 0,
                ],

                'predictions' => [],
            ];
        }

        // Window size
        $windowSize = min(
            7,
            count($timeSeries)
        );

        $recentData = array_slice(
            $timeSeries,
            $windowSize
        );

        // Average count
        $avgCount = array_sum(
            array_column($recentData, 'count')
        ) / $windowSize;

        // Simple trend estimation
        $trend = 0;

        if (count($recentData) >= 2) {
            $first = $recentData[0]['count'];
            $last = end($recentData)['count'];
            $trend = (
                $last  $first
            ) / count($recentData);
        }

        // Generate predictions
        $predictions = [];
        $lastDate = end($timeSeries)['date'];
        for ($i = 1; $i <= $forecastDays; $i++) {
            $nextDate = date(
                'Ymd',
                strtotime($lastDate . " +{$i} days")
            );
            // Trendadjusted prediction
            $prediction = $avgCount + ($trend * $i);
            // Weekend adjustment
            $dayOfWeek = date(
                'N',
                strtotime($nextDate)
            );

            if ($dayOfWeek >= 6) {
                $prediction *= 0.9;
            }

            $prediction = max(
                0,
                round($prediction)
            );

            $predictions[] = [
                'date' => $nextDate,
                'predicted' => $prediction,
                'lower_bound' => max(
                    0,
                    round($prediction * 0.8)
                ),
                'upper_bound' => round(
                    $prediction * 1.2
                ),
                'confidence' => 0.60,
            ];
        }

        return [
            'method' => 'fallback',
            'model' => 'Simple Moving Average',
            'metrics' => [
                'rmse' => 0,
                'mae' => 0,
                'mape' => 0,
            ],
            'predictions' => $predictions,
            'features_used' => [
                'moving_average',
                'trend_estimation',
                'weekend_adjustment'
            ],
        ];
    }
}
